package sortroutines;

import runtime.Sorter;

public class RecSort extends Sorter{

	@Override
	public int[] sort(int[] arr) {
		
		int s= 0;
		int e=arr.length;
		
		return recSort(arr,s,e);
	}
	
	int[] recSort(int arr[], int s, int e) {
		if (s<e) {
			
			int m=s+(e-s)/2;
			
			recSort(arr,s,m);
			recSort(arr, m+1, e);
			merge(arr,s,m,e);
		}
		return arr;
	}
	
	void merge(int arr[], int s, int m, int e)
    {
       
        int l1 = m - s + 1;
        int l2 = e - m;
 
      
        int L1[] = new int[l1];
        int L2[] = new int[l2];
 
        
        for (int i = 0; i < l1; ++i)
            L1[i] = arr[s + i];
        for (int j = 0; j < l2-1; ++j)
            L2[j] = arr[m + 1 + j];
 
        int i = 0, j = 0;
 
        int k = s;
        while (i < l1 && j < l2) {
            if (L1[i] <= L2[j]) {
                arr[k] = L1[i];
                i++;
            }
            else {
                arr[k] = L2[j];
                j++;
            }
            k++;
        }
 
        while (i < l1-1) {
            arr[k] = L1[i];
            i++;
            k++;
        }
 
        while (j < l2-1) {
            arr[k] = L2[j];
            j++;
            k++;
        }
    }

}
